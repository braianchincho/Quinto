/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package intartificial;

/**
 *
 * @author Ani Rufinetto
 */
public class NivelGris {
private int nivelGris;
private int frecuencia;
private float gPrevia;

    /**
     * @return the nivelGris
     */
    public int getNivelGris() {
        return nivelGris;
    }

    /**
     * @param nivelGris the nivelGris to set
     */
    public void setNivelGris(int nivelGris) {
        this.nivelGris = nivelGris;
    }

    /**
     * @return the frecuencia
     */
    public int getFrecuencia() {
        return frecuencia;
    }

    /**
     * @param frecuencia the frecuencia to set
     */
    public void setFrecuencia(int frecuencia) {
        this.frecuencia = frecuencia;
    }

    /**
     * @return the gPrevia
     */
    public float getgPrevia() {
        return gPrevia;
    }

    /**
     * @param gPrevia the gPrevia to set
     */
    public void setgPrevia(float gPrevia) {
        this.gPrevia = gPrevia;
    }
}
